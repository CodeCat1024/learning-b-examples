package com.example.demo.b_return;

public class B_NoResponseBody {
}
