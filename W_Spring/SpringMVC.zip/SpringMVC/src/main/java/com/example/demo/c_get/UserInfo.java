package com.example.demo.c_get;

import lombok.Data;

/**
 * 示范用的对象
 */
@Data
public class UserInfo {
    public String username;
    public String password;
}
